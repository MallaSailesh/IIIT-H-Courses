function sayHello() {
	alert("Hello !")
}
