# ISS ASSIGNMENT 2
## 2021101106
## Malla Sailesh

### Q1
```
inline css :- written in line number 25,29,33,37,41 etc
internal css :- line 4 to 20

click on the image in the website to go to actual image 

click on the lets go to google to go the google 

in the table 2 mention the date and the message to update the news and updates section which is table 3 in the website 
```